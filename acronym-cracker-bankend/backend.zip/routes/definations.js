var express = require('express');
var router = express.Router();
const mysql = require('mysql')

//create a connection pool to access data
const pool = mysql.createPool({
    connectionLimit: 10,
    host: 'aaemxkgpk4z22h.cgykrrl2uwmg.us-east-1.rds.amazonaws.com',
    user: 'felixyudatabase',
    password: 'mySecurePassword',
    database: 'acronym_cracker_database'

})

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('Please pass in an acronym as a parameter');
});

router.get('/:acronym', (req, res) => {
    pool.getConnection((err, conn) => {
      conn.release()
      if(err){
        res.sendStatus(500)
      }
  
      const queryString = 'SELECT * FROM definations WHERE acronym = ?'
      const theAcronym = req.params.acronym
      conn.query(queryString, [theAcronym.trim().toLowerCase()], (err, rows) => {
        if(err){
          res.sendStatus(500)
        }
        res.json(rows)
      })
    })
  })
  

module.exports = router;